# Music Recommendation System (Keras)

This is a basic music recommendation system using collaborative filtering and neural networks.

## Features
- Embedding-based recommendation
- Dummy user/song data
- Predicts rating using dot product + dense layers

## Setup

1. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Run the script:
   ```
   python music_recommender.py
   ```

## Output
Predicts a rating like:
```
Predicted Rating: 3.45
```

## Notes
This is a simulation with dummy data. You can extend it using real-world datasets like Million Song Dataset.
