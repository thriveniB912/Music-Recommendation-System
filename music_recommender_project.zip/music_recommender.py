import numpy as np
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Embedding, Flatten, Dot, Dense
from tensorflow.keras.optimizers import Adam

# Dummy dataset (user_id, song_id, rating)
num_users = 1000
num_songs = 500
embedding_size = 50

# Simulated training data
user_ids = np.random.randint(0, num_users, size=10000)
song_ids = np.random.randint(0, num_songs, size=10000)
ratings = np.random.randint(1, 6, size=10000)

# Inputs
user_input = Input(shape=(1,), name='user_input')
song_input = Input(shape=(1,), name='song_input')

# Embeddings
user_embedding = Embedding(input_dim=num_users, output_dim=embedding_size, name='user_embedding')(user_input)
song_embedding = Embedding(input_dim=num_songs, output_dim=embedding_size, name='song_embedding')(song_input)

# Flatten the embedding vectors
user_vec = Flatten()(user_embedding)
song_vec = Flatten()(song_embedding)

# Dot product of user and song vectors
dot_product = Dot(axes=1)([user_vec, song_vec])

# Dense layers
dense = Dense(64, activation='relu')(dot_product)
output = Dense(1, activation='linear')(dense)

# Build and compile model
model = Model(inputs=[user_input, song_input], outputs=output)
model.compile(optimizer=Adam(learning_rate=0.001), loss='mean_squared_error')

# Train model
model.fit([user_ids, song_ids], ratings, epochs=5, batch_size=64, verbose=1)

# Example prediction
user_test = np.array([15])
song_test = np.array([200])
predicted_rating = model.predict([user_test, song_test])
print(f"Predicted Rating: {predicted_rating[0][0]:.2f}")
